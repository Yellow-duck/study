imgUrl1="images/111.jpg";
imgtext1="YongDa";
imgLink1=escape("http://web.yongda.com");
imgUrl2="images/222.jpg";
imgtext2="maifou";
imgLink2=escape("http://www.maifou.net");
imgUrl3="images/333.jpg";
imgtext3="YongDa";
imgLink3=escape("http://www.wdwd.com");

var pics=imgUrl1+"|"+imgUrl2+"|"+imgUrl3;
var links=imgLink1+"|"+imgLink2+"|"+imgLink3;
var texts=imgtext1+"|"+imgtext2+"|"+imgtext3;