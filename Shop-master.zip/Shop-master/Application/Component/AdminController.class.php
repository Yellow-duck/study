<?php 
namespace Component;
use Think\Controller;
class AdminController extends Controller{
	function __construct(){
		parent::__construct();
        //CONTROLLER_NAME--当前控制器
        //ACTION_NAME--当前方法
        //var_dump($_SESSION['mg_name']);
        if(!$_SESSION['mg_name']){
        	$this->redirect('Manage/login');
        	exit();
        }
        $now_ac = CONTROLLER_NAME."-".ACTION_NAME;
        //echo $now_ac;

		//普通的类都有继承这个控制器，或获得用户能访问的类
		$sql = "select role_auth_ac from sw_manager a join sw_role b on a.mg_role_id=b.role_id where a.mg_id=".$_SESSION['mg_id'];
		$auth_ac=D()->query($sql);
		$auth_ac=$auth_ac[0]['role_auth_ac'];
		//var_dump($auth_ac);

		//Index/left Index/index Index/right Index/head Manager/login
		$allow_ac=array('Index-left','Index-index','Index-right','Index-head');
		if(!in_array($now_ac,$allow_ac) && $_SESSION['mg_id']!=1 && strpos($auth_ac,$now_ac)===false){
			$this->error("没有访问权限",U("Index/right"));
		}
	}
}