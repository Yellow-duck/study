<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
    <head>
        <title>添加权限</title>
        <meta http-equiv="content-type" content="text/html;charset=utf-8">
        <link href="/shop/Public/Admin/css/mine.css" type="text/css" rel="stylesheet">
        <style>
    li{list-style:none;}
        </style>
    
    </head>

    <body>

        <div class="div_head">
            <span>
                <span style="float:left">当前位置是：权限管理-》添加权限信息</span>
                <span style="float:right;margin-right: 8px;font-weight: bold">
                    <a style="text-decoration: none" href="/shop/Admin/Role/showlist">【返回】</a>
                </span>
            </span>
        </div>
        <div></div>

        <div style="font-size: 13px;margin: 10px 5px">
            <form action="/shop/Admin/Role/distribute/role_id/6/" method="post" >
                <div>正在为角色: <span style="font-size:25px;font-weight: bold; "><?php echo ($role_name); ?></span>分配权限</div>
                <!--首先显示父级权限，在内部嵌套判断显示对应的子级权限-->
                <ul>
                    <?php if(is_array($pauth_info)): foreach($pauth_info as $key=>$v): ?><li><?php echo ($v["auth_name"]); ?> <input type="checkbox" name="authname[]" value="<?php echo ($v["auth_id"]); ?>"  <?php if(in_array(($v["auth_id"]), is_array($auth_ids)?$auth_ids:explode(',',$auth_ids))): ?>checked='checked'<?php endif; ?> />
                        <ul>
                        <?php if(is_array($sauth_info)): foreach($sauth_info as $key=>$vv): if(in_array(($vv["auth_pid"]), is_array($v["auth_id"])?$v["auth_id"]:explode(',',$v["auth_id"]))): ?><li><?php echo ($vv["auth_name"]); ?><input type="checkbox" name="authname[]" value="<?php echo ($vv["auth_id"]); ?>" <?php if(in_array(($vv["auth_id"]), is_array($auth_ids)?$auth_ids:explode(',',$auth_ids))): ?>checked='checked'<?php endif; ?> />
                         <ul>
                         <?php if(is_array($tauth_info)): foreach($tauth_info as $key=>$vvv): if(in_array(($vvv["auth_pid"]), is_array($vv["auth_id"])?$vv["auth_id"]:explode(',',$vv["auth_id"]))): ?><li><?php echo ($vvv["auth_name"]); ?><input type="checkbox" name="authname[]" value="<?php echo ($vvv["auth_id"]); ?>" <?php if(in_array(($vvv["auth_id"]), is_array($auth_ids)?$auth_ids:explode(',',$auth_ids))): ?>checked='checked'<?php endif; ?> /></li><?php endif; endforeach; endif; ?>
                         </ul>
                            </li><?php endif; endforeach; endif; ?>
                        </ul>
                         
                    </li><?php endforeach; endif; ?>
                </ul>
                <input type="submit" value="分配权限" />
            </form>
        </div>
    </body>
</html>