<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
    <head>
        <title>添加管理员</title>
        <meta http-equiv="content-type" content="text/html;charset=utf-8">
        <link href="/shop/Public/Admin/css/mine.css" type="text/css" rel="stylesheet">
    </head>

    <body>

        <div class="div_head">
            <span>
                <span style="float:left">当前位置是：管理员管理-》添加管理员信息</span>
                <span style="float:right;margin-right: 8px;font-weight: bold">
                    <a style="text-decoration: none" href="/shop/Admin/Goods/showlist">【返回】</a>
                </span>
            </span>
        </div>
        <div></div>

        <div style="font-size: 13px;margin: 10px 5px">
            <form action="/shop/Admin/Manage/add" method="post" enctype="multipart/form-data">
            <table border="1" width="100%" class="table_a">
                <tr>
                    <td>管理员名称</td>
                    <td><input type="text" name="mg_name" /></td>
                </tr>

                <tr>
                    <td>管理员密码</td>
                    <td><input type="text" name="mg_pwd" /></td>
                </tr>
                                <tr>
                    <td>确认密码</td>
                    <td><input type="text" name="mg_repwd" /></td>
                </tr>
                 <tr>
                    <td>管理员职位</td>
                    <td><select name="mg_role_id" id="">
                            <option value="0" selected="<?php echo ($role_id); ?>">请选择</option> 
                            <?php if(is_array($rinfo)): foreach($rinfo as $k=>$v): ?><option value="<?php echo ($k); ?>" <?php if(in_array(($k), is_array($role_id)?$role_id:explode(',',$role_id))): ?>selected='selected'<?php endif; ?>><?php echo ($v); ?></option><?php endforeach; endif; ?>
                        </select>
                    </td>
                </tr>

                <tr>
                    <td colspan="2" align="center">
                        <input type="submit" value="添加">
                    </td>
                </tr>  
            </table>
            </form>
        </div>
    </body>
</html>