<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>showlist</title>
</head>
<body>
	     <script>
        window.onload = function(){
              showlist('http://localhost/shop/Home/Index/index');
        }
        function showlist(url){
            var xhr=new XMLHttpRequest();
            xhr.onreadystatechange = function(){
                if(xhr.readyState==4){
                  document.getElementById('result').innerHTML=xhr.responseText;
                }
            }
            xhr.open('get',url);
            xhr.send(null);
        }

        </script>
        <div id="result"></div>
</body>
</html>