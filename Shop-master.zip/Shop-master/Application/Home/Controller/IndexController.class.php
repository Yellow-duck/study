<?php
namespace Home\Controller;
use Think\Controller;
class IndexController extends Controller {
    public function index(){
		$goods= D("Goods");
		$total = $goods->count();
		$per=7;
		$page = new \Common\page($total,$per);
		$sql="select * from sw_goods ".$page->limit;
		$info = $goods->query($sql);
		//var_dump($info);
		$pagelist = $page->fpage();
		$p=isset($_GET['page'])?$_GET['page']:1;
		$num=($p-1)*$per;
		//echo $num;

		$this->assign('num',$num);
		$this->assign('info',$info);
		$this->assign('pagelist',$pagelist); 
		$this->display();    
	}
	public function qq(){
		
		$this->display();
	}
	public function gege(){
		$gege=A('Goods');
		$gege->gege();
	}
}