<?php 
namespace Home\Controller;
use Think\Controller;
class UserController extends Controller{
	public function login(){
		$this->display();
	}

	public function register(){
		
		$user=D("User");
		if(!empty($_POST)){
			$user->create();
			$res=$user->add();
			if($res){
				echo 'success';
			}else{
				echo 'false';
			}
		}else{
			$this->display(); 
		}
	    
	}
}
