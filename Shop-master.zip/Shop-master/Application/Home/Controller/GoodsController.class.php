<?php 
namespace Home\Controller;
use Think\Controller;
class GoodsController extends Controller{
	public function detail(){
    	$this->display();
	}

	public function showlist(){
		$this->display();
	}

	public function gege(){
		echo '我叫Goods控制器下的哥哥';
	}
}

