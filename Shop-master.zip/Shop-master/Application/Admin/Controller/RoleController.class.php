<?php  
namespace Admin\Controller;
use Component\AdminController;

class RoleController extends AdminController{
	public function showlist(){
		$info=M("Role")->select();
		//var_dump($info);
		$this->assign('info',$info);
		$this->display();
	}

	public function distribute($role_id){
		if(!empty($_POST)){
			$role = new \Model\RoleModel();
			$z=$role->saveAuth(I('post.authname'),$role_id);
			if($z){
				$this->success('分配权限成功',U('showlist'));
			}else{
				$this->error('分配权限失败',U('showlist'));
			}
			//print_r($_POST);
		}else{
			$rinfo=M("Role")->getByRole_id($role_id);
			//var_dump($rinfo);
			$this->assign('role_name',$rinfo['role_name']);

			//查询全部权限信息，放入模板之中显示并进行分配
			$pauth_info=D('Auth')->where('auth_level=0')->select();//父级权限
			$sauth_info=D('Auth')->where('auth_level=1')->select();//子级权限
			$tauth_info=D('Auth')->where('auth_level=2')->select();//孙级权限
			//var_dump($pauth_info);

			$this->assign('pauth_info',$pauth_info);
			$this->assign('sauth_info',$sauth_info);
			$this->assign('tauth_info',$tauth_info);

			//把当前角色对应的权限信息查询出来
			//$authinfo=M('Role')->getByRole_id($role_id);
			$auth_ids=explode(',',$rinfo['role_auth_ids']);//将字符串分割成数组
			//var_dump($auth_ids);

			$this->assign('auth_ids',$auth_ids);

			$this->display();
		}
	}

	public function add(){
		if(!empty($_POST)){
			$role=M('Role');
			$data['role_name']=I('post.role_name');
			$data['role_auth_ac']='Goods-showlist';
			$result=$role->data($data)->add();
			if($result){
				$this->success('添加角色成功',U('showlist'));
			}else{
				$this->error('添加角色失败',U('showlist'));
			}
		}else{
			$this->display();
		}
	}

	public function del(){
		$role = M('Role');
		$result=$role->where("role_id=%d",I('get.role_id'))->delete();
		if($result){
			$this->success('删除角色成功',U('showlist'));
		}else{
			$this->error('删除角色失败',U('showlist'));
		}
	}
}