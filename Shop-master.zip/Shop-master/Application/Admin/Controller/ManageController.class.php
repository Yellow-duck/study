<?php 
namespace Admin\Controller;
use Think\Controller;

class ManageController extends Controller{
	public function login(){
		if(!empty($_POST)){
			$user= D('Manager');
			if(!$user->create()){
				$this->error($user->getError(),U('login'));
			}else{
				$code= new \Think\Verify();
				if($code->check(I('post.captcha'))){
					//当验证码通过的时候,先判断是否存在该用户，在验证密码
					$info=$user->where("mg_name='%s'",I('post.mg_name'))->select();
		
					if($info==null){
						$this->error('该用户不存在！',U('login'));
					}else{
						//var_dump($info);
						//exit();
						if(I('post.mg_pwd')==$info[0]['mg_pwd']){
							//var_dump($info);
							//exit();
							session('mg_name',$info[0]['mg_name']);
							session('mg_id',$info[0]['mg_id']);
							$this->redirect('Index/index');
						}else{
							$this->error('密码错误,请联系管理员！',U('login'));
						}
					}
				}else{
					$this->error('验证码错误!',U('login'));
				}
			}	
		}else{
			$this->display();
		}	
	}

	public function logout(){
		session(null);
		$this->redirect('Manage/login');
	}

	public function verify(){
		$config = array(
        'fontSize'  =>  14,              // 验证码字体大小(px)
        'imageH'    =>  24,               // 验证码图片高度
        'imageW'    =>  105,               // 验证码图片宽度
        'length'    =>  1,               // 验证码位数
        'fontttf'   =>  '4.ttf',              // 验证码字体，不设置随机获取
			);
		$code= new \Think\Verify($config);
		$code->entry();
	}
	
	public function showlist(){
		$info=D('Manager')->select();
		//查询全部的角色信息
		$rinfo=$this->getRoleInfo();
        //var_dump($rinfo);
		$this->assign('rinfo',$rinfo);
		$this->assign('info',$info);
		$this->display();
	}

	public function upd($mg_id){
		if(!empty($_POST)){
			//var_dump($_POST);
			$manager=D('Manager');
			$manager->create();
			$z=$manager->save();
			if($z){
				$this->success('修改管理员成功!',U('showlist'));
			}else{
				$this->error('修改管理员失败!',U('showlist'));
			}
		}else{
			//获得被修改管理员信息
			$info = D('Manager')->find($mg_id);
			//获取角色信息
			$rinfo=$this->getRoleInfo();

			$this->assign('role_id',$info['mg_role_id']);
			$this->assign('rinfo',$rinfo);
			$this->assign('info',$info);
			$this->assign('mg_id',$mg_id);
			$this->display();
		}
	}

	public function add(){
		if(!empty($_POST)){
			$rules = array(
		     array('mg_name','require','管理员名称必须填写!'), 
		     array('mg_pwd','require','管理员密码必须填写!'),
		     array('mg_pwd','/^[0-9a-zA-Z][0-9a-zA-Z]{2,14}[0-9a-zA-Z]$/','密码只能是6-16个长度!',0,'regex'),  
 			 array('mg_repwd','require','请填写确认密码!'), 
		     array('mg_role_id',array(0),'请选择管理员职位！',1,'notin'), 
		     array('mg_repwd','mg_pwd','确认密码不正确',0,'confirm'), // 验证确认密码是否和密码一致
			);

			$User = M("Manager"); // 实例化User对象
			if (!$User->validate($rules)->create()){
			     // 如果创建失败 表示验证没有通过 输出错误提示信息
			     $this->error($User->getError(),U('Manage/add'));
			}else{
			    // 验证通过 可以进行其他数据操作
				//收集表单数据
				$data=array();
				$data['mg_name']=I('post.mg_name');
				$data['mg_pwd']=I('post.mg_pwd');
				$data['mg_role_id']=I('post.mg_role_id');
				$data['mg_time']=time();
				$result=$User->data($data)->add();
				if($result){
					$this->success('管理员添加成功!',U('Manage/showlist'));
				}else{
					$this->error('管理员添加失败!',U('Manage/add'));
				}
			}
		}else{
			$rinfo=$this->getRoleInfo();
			$this->assign('rinfo',$rinfo);
			$this->display();
		}
	}

	public function del(){
		$user = M('Manager');
		$result = $user->where("mg_id=%d",I('get.mg_id'))->delete();
		if($result){
			$this->success('管理员删除成功!',U('Manage/showlist'));
		}else{
			$this->error('管理员删除失败!',U('Manage/add'));
		}
	}

	public function getRoleInfo(){
		//查询全部角色的信息
		$rrinfo=D('Role')->select();
		//array(1=>'经理',2=>'主管')
		$rinfo=array();
		foreach ($rrinfo as $k => $v) {
			$rinfo[$v['role_id']]=$v['role_name'];
		}
		return $rinfo;
	}
}
