<?php
namespace Admin\Controller;
use Component\AdminController;

class AdvertController extends AdminController{
	public function showlist(){
		echo '暂时没有，敬请期待！';
	}

	public function position(){
		echo '暂时没有，敬请期待！';
	}
}