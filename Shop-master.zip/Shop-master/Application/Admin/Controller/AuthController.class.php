<?php  
namespace Admin\Controller;
use Component\AdminController;

class AuthController extends AdminController{
	function showlist(){
		$info=$this->getInfo();
		$this->assign('info',$info);
		$this->display();
	}

	function add(){
		if(!empty($_POST)){
        	//var_dump($_POST);  
        	//建立AuthModel类来处理添加的成员
        	$User = D("Auth"); // 实例化User对象
			if (!$User->create()){
			     // 如果创建失败 表示验证没有通过 输出错误提示信息
			     $this->error($User->getError(),U('Auth/add'));
			}else{
			     // 验证通过 可以进行其他数据操作
				$auth = new \Model\AuthModel();
	        	$z=$auth->addAuth(I('post.'));
	        	if($z){
	        		$this->success('添加权限成功!',U('showlist'));
	        	}else{
	        		$this->error('添加权限失败!',U('showlist'));
	        	}
			}	
		}else{
			$info=$this->getInfo(true);
			//var_dump($info);
			$authinfo=array();
			foreach ($info as $k => $v) {
				$authinfo[$v['auth_id']]=$v['auth_name'];
			}
            //var_dump($authinfo);
			$this->assign('authinfo',$authinfo);
			$this->display();
		}
	}

	function getInfo($flag=false){
		//如果flag标志为false,查询全部的权限信息
		//如果flag标志为true,只查询level=0/1的权限
		$auth=M('Auth');
		if($flag==true){
			$info=M("Auth")->where('auth_level<2')->order('auth_path asc')->select();
		}else{
			$info=M("Auth")->order('auth_path asc')->select();
		}
		//为了显示好看，加上一个连接符代表层次关系
		foreach ($info as $k => $v) {
			$info[$k]['auth_name']=str_repeat('-->',$v['auth_level']).$info[$k]['auth_name'];
		}
		return $info;
	}
}