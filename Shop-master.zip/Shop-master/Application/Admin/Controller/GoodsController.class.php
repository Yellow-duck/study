<?php
namespace Admin\Controller;
use Component\AdminController;

class GoodsController extends AdminController{
	public function showlist(){
		$goods= M("Goods");
		$total = $goods->count();
		$per=7;
		$num = I('get.page')?I('get.page'):1;
        $num=($num-1)*$per;
		$page = new \Common\page($total,$per);
		$sql="select * from sw_goods where goods_show=1 ".$page->limit;
		$info = $goods->query($sql);
		//var_dump($info);
		$pagelist = $page->fpage();

		$this->assign('num',$num);
		$this->assign('info',$info);
		$this->assign('pagelist',$pagelist); 
		$this->display();
	}

	public function add(){
		if(!empty($_POST)){
            //如果上传文件成功
			if(!empty($_FILES)){
				$config=array(
                	'rootPath'      =>  './public/', //保存根路径
                    'savePath'      =>  'upload/', //保存路径  
                    'maxSize'    =>    3145728, 
                    'exts'       =>    array('jpg', 'gif', 'png', 'jpeg'), 
					);

				$upload = new \Think\Upload($config);
				$z=$upload->uploadOne($_FILES['goods_image']);
				if(!$z){
					echo $upload->getError();
				}else{
					//以下进行添加字段的自动验证
					$rules=array(
						array('goods_name','require','商品名必须！'), 
					    array('goods_weight','require','商品重量必须填写'), 
					    array('goods_price','require','商品价格必须填写'), 
					    array('goods_number','require','商品数量必须填写'),
					    array('goods_introduce','require','商品简介必须填写'),
						);
					$goods = M("Goods");
					if (!$goods->validate($rules)->create()){
					     // 如果创建失败 表示验证没有通过 输出错误提示信息
					     $this->error($goods->getError(),U('Goods/add'));
					}else{
					     // 验证通过 可以进行其他数据操作
						//拼装图片的路径名
						$bigimg=$z['savepath'].$z['savename'];
						$_POST['goods_big_img']=$bigimg;
						//制作缩略图
						$image = new \Think\Image();
						$srcimg=$upload->rootPath.$bigimg;
						$image->open($srcimg);
						$image->thumb(150,150);
						$smallimg=$z['savepath']."small_".$z['savename'];
						$image->save($upload->rootPath.$smallimg);
						$_POST['goods_small_img']=$smallimg;
						$_POST['goods_create_time']=time();
						//收集数据并进行数据插入
						$data = I('post.');
						$res=$goods->data($data)->add();
						if(!$res){
							$this->error('商品信息添加失败!',U('Goods/add'));
						}else{
							$this->success('商品信息添加成功!',U('Goods/showlist'));
						}
					}				
				}
			}			
		}else{
			$this->display();
		}	
	}

	public function upd(){
		$goods=M('Goods');
		$info = $goods->where("goods_id=%d",I('get.goods_id'))->find();
		if(!empty($_POST)){
            //如果上传文件成功
			if(!empty($_FILES)){
				$config=array(
                	'rootPath'      =>  './public/', //保存根路径
                    'savePath'      =>  'upload/', //保存路径  
                    'maxSize'    =>    3145728, 
                    'exts'       =>    array('jpg', 'gif', 'png', 'jpeg'), 
					);

				$upload = new \Think\Upload($config);
				$z=$upload->uploadOne($_FILES['goods_image']);
				if(!$z){
					echo $upload->getError();
				}else{
					//进行数据处理
                    $goods=D('Goods');
                    $info = $goods->where("goods_id=%d",I('post.goods_id'))->find();
                    if(!$goods->create()){
                    	$this->error($goods->getError(),U('Goods/upd',array('goods_id'=>I('post.goods_id'))));
                    }else{

						//删除已存在的图片
						unlink($upload->rootPath.$info['goods_big_img']);
						unlink($upload->rootPath.$info['goods_small_img']);
						//拼装图片的路径名
						$bigimg=$z['savepath'].$z['savename'];
						$_POST['goods_big_img']=$bigimg;
						//制作缩略图
						$image = new \Think\Image();
						$srcimg=$upload->rootPath.$bigimg;
						$image->open($srcimg);
						$image->thumb(150,150);
						$smallimg=$z['savepath']."small_".$z['savename'];
						$image->save($upload->rootPath.$smallimg);
						$_POST['goods_small_img']=$smallimg;
						$_POST['goods_last_time']=time();
						//收集数据并进行数据插入
                    	$data=I('post.');
                    	$res=$goods->data($data)->save();
						if(!$res){
							$this->error('商品信息修改失败!',U('Goods/upd'));
						}else{
							$this->success('商品信息修改成功!',U('Goods/showlist'));
						}
                    }  	
				}
					
			}else{
				$this->error('你还没有上传文件!',U('Goods/showlist'));
			}		
		}else{
			//dump($info);
			$this->assign('info',$info);
			$this->display();	
		}

	}

	public function del($goods_id){
		$goods=M('Goods');
		$data['goods_show']= 0;
		$data['goods_last_time']=time();
		//将不要的商品数据暂时存放在垃圾回收站
		$result=$goods->where("goods_id=%d",$goods_id)->save($data);
        if($result){
        	$this->success('商品删除成功!',U('Goods/showlist'));
        }else{
        	$this->error('商品删除失败!',U('Goods/showlist'));
        }
	}
}