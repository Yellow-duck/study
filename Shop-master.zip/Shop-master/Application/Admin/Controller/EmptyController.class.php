<?php  
namespace Admin\Controller;
use Think\Controller;
class EmptyController extends Controller{
	function _empty(){
		echo "<img src='/shop/Public/Admin/img/1.jpg'/>";
	}
}