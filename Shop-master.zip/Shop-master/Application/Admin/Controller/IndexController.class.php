<?php
namespace Admin\Controller;
use Component\AdminController;

class IndexController extends AdminController {
    public function index(){
        $this->display();
    }

    public function head(){
    	//var_dump(get_defined_constants(true));
    	$this->display(); 
    }

    public function left(){
        $sql = "select * from sw_manager where mg_id=".$_SESSION['mg_id'];
        $minfo=D()->query($sql);
        //var_dump($minfo);
        $role_id=$minfo[0]['mg_role_id'];

        $sql = "select *from sw_role where role_id=".$role_id;
        $rinfo=D()->query($sql);
        $auth_ids=$rinfo[0]['role_auth_ids'];
        //var_dump($auth_ids);
        
        //父级权限   
        $sql = "select * from sw_auth where auth_level=0 ";
        if($_SESSION['mg_id']!=1){
            $sql.="and auth_id in($auth_ids)";
        }
        $painfo=D()->query($sql);
        //var_dump($painfo);

        //子级权限
        $sql = "select * from sw_auth where auth_level=1 ";
        if($_SESSION['mg_id']!=1){
            $sql.="and auth_id in($auth_ids)";
        }
        $sainfo=D()->query($sql);

        $this->assign('painfo',$painfo);
        $this->assign('sainfo',$sainfo);
    	$this->display();
    }

    public function right(){
    	$this->display();
    }
}