<?php
namespace Admin\Controller;
use Component\AdminController;

class RecycleController extends AdminController{
	public function goods(){
		$goods= M("Goods");
		$total = $goods->where('goods_show=0')->count();
		$per=7;
		$num = I('get.page')?I('get.page'):1;
        $num=($num-1)*$per;
		$page = new \Common\page($total,$per);
		//将放入回收站的商品按删除的时间来排序
		$sql="select * from sw_goods where goods_show=0 order by goods_last_time desc ".$page->limit;
		$info = $goods->query($sql);
		//var_dump($info);
		$pagelist = $page->fpage();

		$this->assign('num',$num);
		$this->assign('info',$info);
		$this->assign('pagelist',$pagelist); 
		$this->display();
	}

	public function recover($goods_id){
		$goods=M('Goods');
		$data['goods_show']= 1;
		//将存放在垃圾回收站的数据还原
		$result=$goods->where("goods_id=%d",$goods_id)->save($data);
        if($result){
        	$this->success('商品还原成功!',U('Recycle/goods'));
        }else{
        	$this->error('商品还原失败!',U('Recycle/goods'));
        }
	}

	public function del($goods_id){
		$goods=M('Goods');
		$result=$goods->where("goods_id=%d",$goods_id)->delete();
		if($result){
        	$this->success('商品删除成功!',U('Recycle/goods'));
        }else{
        	$this->error('商品删除失败!',U('Recycle/goods'));
        }
	}
}