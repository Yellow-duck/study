<?php 
namespace Admin\Model;
use Think\Model;
class AuthModel extends Model{
   protected $_validate = array(
     array('auth_name','require','权限名称必须填写！'), //默认情况下用正则进行验证
     array('auth_c','require','控制器必须填写'), 
     array('auth_a','require','控制器方法必须填写'), 
     array('auth_c','/^[A-Za-z]+$/','控制器只能是字母',0,'regex'),
     array('auth_a','/^[A-Za-z]+$/','控制器方法只能是字母',0,'regex'),
   );
}
