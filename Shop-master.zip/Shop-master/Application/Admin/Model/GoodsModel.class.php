<?php 
namespace Admin\Model;
use Think\Model;
class GoodsModel extends Model{
   protected $_validate = array(
     array('goods_name','require','商品名必须！'), 
     array('goods_weight','require','商品重量必须填写'), 
     array('goods_price','require','商品价格必须填写'), 
     array('goods_number','require','商品数量必须填写'),
     array('goods_introduce','require','商品简介必须填写'),
   );
}