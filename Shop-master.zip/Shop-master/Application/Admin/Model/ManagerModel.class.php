<?php  
namespace Admin\Model;
use Think\Model;
class ManagerModel extends Model{
   protected $_validate = array(
     array('captcha','require','验证码必须！'), //默认情况下用正则进行验证
     array('mg_name','require','用户名必须填写'), // 
     array('mg_pwd','require','密码必须填写'), // 
   );
}
