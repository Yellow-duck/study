<?php
return array(	
	//'配置项'=>'配置值' 
	//本地数据库配置
	'DB_TYPE'   =>  'mysql',     // 数据库类型
	'DB_HOST'   =>  'localhost', // 服务器地址
	'DB_NAME'   =>  'shop',          // 数据库名
	'DB_USER'   =>  'root',      // 用户名
	'DB_PWD'    =>  '123123',          // 密码
	'DB_PORT'   =>  '3306',        // 端口
	'DB_PREFIX' =>  'sw_',    // 数据库表前缀
	
    //阿里云数据库配置
	/*'DB_TYPE'   =>  'mysql',     // 数据库类型
	'DB_HOST'   =>  'bdm256642151.my3w.com', // 服务器地址
	'DB_NAME'   =>  'bdm256642151_db',          // 数据库名
	'DB_USER'   =>  'bdm256642151',      // 用户名
	'DB_PWD'    =>  'qq13537320163',          // 密码
	'DB_PORT'   =>  '3306',        // 端口
	'DB_PREFIX' =>  'sw_',    // 数据库表前缀
	*/
	//框架自带Think模板引擎，可切换Smarty模板引擎
	'TMPL_ENGINE_TYPE'      =>  'Think',
	//框架默认为URL路径为pathinfo模式,可根据需求修改
	'URL_MODEL' => 2,//通过url重写和.htaccess隐藏入口文件index.php

	//开发的时候建议开始，有利于调试
	//'SHOW_PAGE_TRACE'=>true,

/***修改I函数底层过滤时使用的函数,可以设置多个过滤规则,但中间不能有空格********/
	'DEFAULT_FILTER' => 'trim,htmlspecialchars,strip_tags,stripslashes',

);