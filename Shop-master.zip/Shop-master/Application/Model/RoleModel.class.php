<?php
namespace Model;
use Think\Model;  
class RoleModel extends Model{
	//权限分配
	//$auth是一维数组，给当前的角色分配权限的id
	function saveAuth($auth,$role_id){
		//将一维数组的权限id拼装成用逗号分块的字符窜
		$auth_ids=implode(',',$auth);
        //var_dump($auth_ids);
        $info=M("Auth")->select($auth_ids);
        //var_dump($info);
        $auth_ac='';
        foreach($info as $k => $v){
        	if(!empty($v['auth_c']) && !empty($v['auth_a'])){
        	$auth_ac.=$v['auth_c']."-".$v['auth_a'].",";
            }
        }
        //去掉右边多余的(,);
        $auth_ac = rtrim($auth_ac,',');
        //var_dump($auth_ac); 
        $dt = array(
        	'role_id'=>$role_id,
        	'role_auth_ids'=>$auth_ids,
        	'role_auth_ac'=>$auth_ac,
        	);
        return $this->save($dt);
	}
}