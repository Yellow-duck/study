<?php
return array(
	'DEFAULT_FILTER' => 'stripslashes,htmlspecialchars',
);