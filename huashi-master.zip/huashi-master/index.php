<?php

define('APP_PATH', './../huashi_port/');
define('THINK_PATH', realpath('../tp323/ThinkPHP').'/');

define('RUNTIME_PATH','./Runtime/');
define('APP_DEBUG', true);

require THINK_PATH.'ThinkPHP.php';



?>