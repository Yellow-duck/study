<?php
namespace Home\Controller;

class ServeController extends BaseController {
    public function index(){
        $this->display();
    }
}