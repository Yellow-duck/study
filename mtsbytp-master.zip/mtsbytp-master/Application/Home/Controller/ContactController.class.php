<?php
namespace Home\Controller;

class ContactController extends BaseController {
    public function index(){
        $this->display();
    }
    public function map(){
        $this->display();
    }
}