<?php
namespace Admin\Controller;
use Think\Controller;
class ChatController extends Controller
{
    
    public function index(){

        
        $this->display();
    }
}