##dwz后端框架 + ThinkPHP 3.2.3

### fork from https://code.csdn.net/dwzteam/dwz_thinkphp 

### 背景

由于很久之前内部系统需要，需要使用一个后台框架，但是，TP3.1.3 受不了啊，所以就改成3.2.3了。感谢 dwz http://j-ui.com

### 配置

1、git clone 

2、导入 dwz_thinkphp.sql 数据库

3、配置数据库，打开Application/Common/Conf/db.php 

4、设置 Application/Runtime 文件夹读写

```
chmod -R 777 Application/Runtime
```
5、have fun

