<?php

return array(
    'SITENAME' => 'DWZ富客户端框架 - thinkphp3.0',
    'EMAIL' => 'zhanghuihua@dwzjs.com',
    'CONTACT' => '张慧华',
    'COMPANY' => 'dwz研发组',
    'PHONE' => '',
    'FAX' => '',
    'ADDRESS' => '',
    'OFFLINEMESSAGE' => '本站正在维护中，暂不能访问。<br /> 请稍后再访问本站。',
    'SITEURL' => 'http://thinkphp.dwzjs.com',
    'DEMOURL' => 'http://demo.dwzjs.com',
    'BBSOURL' => 'http://bbs.dwzjs.com',
);
